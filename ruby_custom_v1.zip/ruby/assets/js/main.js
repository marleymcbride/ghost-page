(function () {
    // Simple pagination function - no-op if not needed
    function pagination(enable) {
        // Placeholder for pagination functionality
        return enable;
    }

    pagination(true);

    // Auth Modal functionality
    function initAuthModal() {
        const modal = document.getElementById('auth-modal');
        const trigger = document.querySelector('.auth-modal-trigger');
        const closeBtn = document.querySelector('.auth-modal-close');
        const overlay = document.querySelector('.auth-modal-overlay');

        if (!modal || !trigger) return;

        // Open modal
        function openModal() {
            modal.style.display = 'flex';
            modal.setAttribute('data-state', 'open');
            document.body.style.overflow = 'hidden';

            // Focus management for accessibility
            setTimeout(() => {
                const firstButton = modal.querySelector('.auth-btn');
                if (firstButton) firstButton.focus();
            }, 100);
        }

        // Close modal
        function closeModal() {
            modal.setAttribute('data-state', 'closing');
            document.body.style.overflow = '';

            setTimeout(() => {
                modal.style.display = 'none';
                modal.removeAttribute('data-state');
                trigger.focus(); // Return focus to trigger
            }, 200);
        }

        // Event listeners
        trigger.addEventListener('click', openModal);

        if (closeBtn) {
            closeBtn.addEventListener('click', closeModal);
        }

        if (overlay) {
            overlay.addEventListener('click', closeModal);
        }

        // Close on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.style.display === 'flex') {
                closeModal();
            }
        });

        // Handle portal links within modal
        const portalLinks = modal.querySelectorAll('[data-portal]');
        portalLinks.forEach(link => {
            link.addEventListener('click', function() {
                // Close modal when portal opens
                closeModal();
            });
        });
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAuthModal);
    } else {
        initAuthModal();
    }
})();
